import React, { createContext, useContext, useState, useEffect } from 'react';
import { jwtDecode } from 'jwt-decode';
import apiClient from '../services/api';
import { User, UserRole } from '../types';
import { toast } from '../components/common/Toaster';

interface DecodedToken {
  exp: number;
  sub: string;
  role: UserRole;
}

interface AuthContextType {
  user: User | null;
  currentRole: UserRole | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
  getToken: () => string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('accessToken'));
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const initializeAuth = async () => {
      if (token) {
        try {
          const decodedToken: DecodedToken = jwtDecode(token);
          if (decodedToken.exp * 1000 > Date.now()) {
            // Token is valid, now fetch the full user object
            const response = await apiClient.get('/api/users/me');
            setUser(response.data);
          } else {
            logout();
          }
        } catch (error) {
          console.error("Failed to initialize auth state:", error);
          logout();
        }
      }
      setIsLoading(false);
    };
    initializeAuth();
  }, [token]);

  const login = async (email: string, password: string) => {
    const body = new URLSearchParams();
    body.append('username', email);
    body.append('password', password);

    try {
        const response = await apiClient.post('/api/login/access-token', body, {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        });

        const newAccessToken = response.data.access_token;
        localStorage.setItem('accessToken', newAccessToken);
        apiClient.defaults.headers.common['Authorization'] = `Bearer ${newAccessToken}`; // Update instance defaults
        setToken(newAccessToken);
        // The useEffect will handle fetching user data upon token change
    } catch(error: any) {
        const errorMessage = error.response?.data?.detail || 'Invalid email or password';
        toast.error(errorMessage);
        throw new Error(errorMessage);
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('accessToken');
    delete apiClient.defaults.headers.common['Authorization'];
  };

  const getToken = () => token;

  return (
    <AuthContext.Provider value={{ user, currentRole: user?.role || null, login, logout, isLoading, getToken }}>
      {children}
    </AuthContext.Provider>
  );
}