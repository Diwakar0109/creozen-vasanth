import React, { useState, useEffect } from 'react';
import { X, Send, User, Calendar, FileText, Pill, Trash2 } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { Appointment, Visit, PrescriptionMedicine } from '../../types';
import apiClient from '../../services/api';
import { toast } from '../common/Toaster';

interface ConsultationModalProps {
  appointment: Appointment;
  onClose: () => void;
}

export default function ConsultationModal({ appointment, onClose }: ConsultationModalProps) {
  const { user } = useAuth();
  const patient = appointment.patient;
  
  const [patientHistory, setPatientHistory] = useState<Visit[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  // Form states
  const [visitData, setVisitData] = useState({ subjective: '', objective: '', assessment: '', plan: '', private_note: '' });
  const [prescriptionMedicines, setPrescriptionMedicines] = useState<Omit<PrescriptionMedicine, 'id'>[]>([]);
  
  // UI states
  const [showAddMedicine, setShowAddMedicine] = useState(false);
  const [newMedicine, setNewMedicine] = useState({ medicine_name: '', dose: '', frequency: '', duration_days: 7, instructions: '' });
  const [activeTab, setActiveTab] = useState('consultation');
  const [isCompleting, setIsCompleting] = useState(false);

  useEffect(() => {
    const fetchHistory = async () => {
      if (activeTab === 'history' && patient?.id) {
        setHistoryLoading(true);
        try {
          const response = await apiClient.get<Visit[]>(`/api/patients/${patient.id}/visits`);
          setPatientHistory(response.data);
        } catch (error) {
          toast.error("Could not load patient history.");
          setPatientHistory([]); // Clear history on error
        } finally {
          setHistoryLoading(false);
        }
      }
    };
    fetchHistory();
  }, [activeTab, patient?.id]);

  const addMedicine = () => {
    if (newMedicine.medicine_name && newMedicine.dose && newMedicine.frequency) {
      setPrescriptionMedicines(prev => [...prev, { ...newMedicine }]);
      setNewMedicine({ medicine_name: '', dose: '', frequency: '', duration_days: 7, instructions: '' });
      setShowAddMedicine(false);
    } else {
      toast.error("Medicine Name, Dose, and Frequency are required.");
    }
  };

  const removeMedicine = (index: number) => {
    setPrescriptionMedicines(prev => prev.filter((_, i) => i !== index));
  };

  const handleCompleteVisit = async () => {
    setIsCompleting(true);
    try {
      const payload = {
        visit_details: visitData,
        prescription_details: { line_items: prescriptionMedicines }
      };
      await apiClient.put(`/api/appointments/${appointment.id}/status/complete`, payload);
      toast.success("Consultation completed successfully.");
      onClose();
    } catch (error) {
      toast.error("Failed to complete consultation.");
    } finally {
      setIsCompleting(false);
    }
  };

  if (!patient) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-2xl max-w-6xl w-full mx-4 max-h-[95vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b flex items-center justify-between">
            <h2 className="text-xl font-semibold text-gray-900">{patient.full_name} ({patient.sex}, DOB: {patient.date_of_birth || 'N/A'})</h2>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg"><X size={20} /></button>
        </div>

        {/* Tabs */}
        <div className="border-b">
          <nav className="px-6 flex space-x-8">
            <button onClick={() => setActiveTab('consultation')} className={`py-4 px-2 border-b-2 font-medium text-sm ${activeTab === 'consultation' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>Consultation</button>
            <button onClick={() => setActiveTab('history')} className={`py-4 px-2 border-b-2 font-medium text-sm ${activeTab === 'history' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>Patient History</button>
            <button onClick={() => setActiveTab('prescription')} className={`py-4 px-2 border-b-2 font-medium text-sm ${activeTab === 'prescription' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>Prescription</button>
          </nav>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'consultation' && (
            <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Subjective</label>
                  <textarea rows={4} value={visitData.subjective} onChange={(e) => setVisitData(prev => ({ ...prev, subjective: e.target.value }))} className="w-full border rounded-md p-2"/>
                </div>
                 <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Objective</label>
                  <textarea rows={4} value={visitData.objective} onChange={(e) => setVisitData(prev => ({ ...prev, objective: e.target.value }))} className="w-full border rounded-md p-2"/>
                </div>
                 <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Assessment (Diagnosis)</label>
                  <textarea rows={4} value={visitData.assessment} onChange={(e) => setVisitData(prev => ({ ...prev, assessment: e.target.value }))} className="w-full border rounded-md p-2"/>
                </div>
                 <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Plan</label>
                  <textarea rows={4} value={visitData.plan} onChange={(e) => setVisitData(prev => ({ ...prev, plan: e.target.value }))} className="w-full border rounded-md p-2"/>
                </div>
                 <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Private Clinical Notes (Only visible to you)</label>
                  <textarea rows={3} value={visitData.private_note} onChange={(e) => setVisitData(prev => ({ ...prev, private_note: e.target.value }))} className="w-full border rounded-md p-2"/>
                </div>
            </div>
          )}

          {activeTab === 'history' && (
             <div>
                <h3 className="font-semibold text-gray-900 mb-4">Visit History</h3>
                {historyLoading ? (
                    <p>Loading history...</p>
                ) : patientHistory.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                        <Calendar className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                        <p>No previous visits found for this patient.</p>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {patientHistory.map(visit => (
                            <div key={visit.id} className="border border-gray-200 rounded-lg p-4">
                                <p className="text-sm text-gray-500 mb-2">Visit ID: {visit.id}</p>
                                {visit.assessment && <p><strong className="font-medium">Assessment:</strong> {visit.assessment}</p>}
                                {visit.plan && <p className="mt-1"><strong className="font-medium">Plan:</strong> {visit.plan}</p>}
                                {visit.authored_notes && visit.authored_notes.length > 0 && (
                                    <div className="mt-2 p-2 bg-yellow-50 border-l-4 border-yellow-400">
                                        <p className="font-medium text-yellow-800">Your Private Notes:</p>
                                        <p className="text-sm text-yellow-700">{visit.authored_notes[0].content}</p>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                )}
             </div>
          )}

          {activeTab === 'prescription' && (
             <div className="space-y-6">
                <div className="flex items-center justify-between">
                    <h3 className="font-semibold text-gray-900">Add Medicines to Prescription</h3>
                    <button onClick={() => setShowAddMedicine(true)} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm font-medium">Add Medicine</button>
                </div>
                {showAddMedicine && (
                    <div className="border rounded-lg p-4 bg-gray-50 grid grid-cols-3 gap-4">
                       <div><label>Name*</label><input value={newMedicine.medicine_name} onChange={e => setNewMedicine(p => ({...p, medicine_name: e.target.value}))} className="w-full border rounded-md p-2 mt-1"/></div>
                       <div><label>Dose*</label><input value={newMedicine.dose} onChange={e => setNewMedicine(p => ({...p, dose: e.target.value}))} className="w-full border rounded-md p-2 mt-1"/></div>
                       <div><label>Frequency*</label><input value={newMedicine.frequency} onChange={e => setNewMedicine(p => ({...p, frequency: e.target.value}))} className="w-full border rounded-md p-2 mt-1"/></div>
                       <div><label>Duration (days)</label><input type="number" value={newMedicine.duration_days} onChange={e => setNewMedicine(p => ({...p, duration_days: parseInt(e.target.value)}))} className="w-full border rounded-md p-2 mt-1"/></div>
                       <div className="col-span-2"><label>Instructions</label><input value={newMedicine.instructions} onChange={e => setNewMedicine(p => ({...p, instructions: e.target.value}))} className="w-full border rounded-md p-2 mt-1"/></div>
                       <div className="col-span-3 flex justify-end space-x-2"><button onClick={() => setShowAddMedicine(false)} className="px-3 py-1 border rounded">Cancel</button><button onClick={addMedicine} className="px-3 py-1 bg-blue-600 text-white rounded">Add</button></div>
                    </div>
                )}
                <div className="space-y-3">
                    {prescriptionMedicines.map((med, index) => (
                        <div key={index} className="border rounded-lg p-3 flex justify-between items-center">
                            <div>
                                <p className="font-medium">{med.medicine_name}</p>
                                <p className="text-sm text-gray-500">{med.dose} - {med.frequency} - {med.duration_days} days</p>
                            </div>
                            <button onClick={() => removeMedicine(index)} className="text-red-500 hover:text-red-700 p-1"><Trash2 size={16}/></button>
                        </div>
                    ))}
                    {prescriptionMedicines.length === 0 && !showAddMedicine && (
                         <div className="text-center py-8 text-gray-500">No medicines added yet.</div>
                    )}
                </div>
             </div>
          )}
        </div>
        
        {/* Footer */}
        <div className="px-6 py-4 border-t flex justify-end space-x-3">
            <button onClick={onClose} className="px-4 py-2 border rounded-lg hover:bg-gray-50 font-medium">Cancel</button>
            <button onClick={handleCompleteVisit} disabled={isCompleting} className="flex items-center space-x-2 px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium disabled:opacity-50">
              <Send className="h-4 w-4" />
              <span>{isCompleting ? 'Completing...' : 'Complete Visit'}</span>
            </button>
        </div>
      </div>
    </div>
  );
}