import React, { useState } from 'react';
import { X, Save, Send, User, Calendar, FileText, Pill } from 'lucide-react';
import { useData } from '../../contexts/DataContext';
import { useAuth } from '../../contexts/AuthContext';
import { Visit, Prescription, PrescriptionMedicine } from '../../types';

interface ConsultationModalProps {
  appointment: any;
  onClose: () => void;
}

export default function ConsultationModal({ appointment, onClose }: ConsultationModalProps) {
  const { patients, updateAppointment, addVisit, addPrescription, getPatientHistory } = useData();
  const { user } = useAuth();
  
  const patient = patients.find(p => p.id === appointment.patientId);
  const patientHistory = getPatientHistory(appointment.patientId);
  
  const [visitData, setVisitData] = useState({
    subjective: '',
    objective: '',
    assessment: '',
    plan: '',
    clinicalNotes: '',
    clinicalNotesPrivate: true
  });

  const [prescriptionMedicines, setPrescriptionMedicines] = useState<Omit<PrescriptionMedicine, 'id' | 'status'>[]>([]);
  const [showAddMedicine, setShowAddMedicine] = useState(false);
  const [newMedicine, setNewMedicine] = useState({
    name: '',
    dose: '',
    frequency: '',
    route: 'Oral',
    duration: 7,
    instructions: ''
  });

  const [activeTab, setActiveTab] = useState('consultation');
  const [isLoading, setIsLoading] = useState(false);

  const addMedicine = () => {
    if (newMedicine.name && newMedicine.dose && newMedicine.frequency) {
      setPrescriptionMedicines(prev => [...prev, { ...newMedicine }]);
      setNewMedicine({
        name: '',
        dose: '',
        frequency: '',
        route: 'Oral',
        duration: 7,
        instructions: ''
      });
      setShowAddMedicine(false);
    }
  };

  const removeMedicine = (index: number) => {
    setPrescriptionMedicines(prev => prev.filter((_, i) => i !== index));
  };

  const handleCompleteVisit = async () => {
    setIsLoading(true);
    try {
      // Create visit record
      const visit: Omit<Visit, 'id'> = {
        appointmentId: appointment.id,
        patientId: appointment.patientId,
        doctorId: user?.id || '1',
        hospitalId: appointment.hospitalId,
        date: new Date(),
        ...visitData,
        status: 'completed',
        completedAt: new Date(),
        attachments: [],
        vitals: {}
      };

      addVisit(visit);

      // Create prescription if medicines exist
      if (prescriptionMedicines.length > 0) {
        const prescription: Omit<Prescription, 'id' | 'createdAt'> = {
          visitId: '1', // Would be the actual visit ID
          patientId: appointment.patientId,
          doctorId: user?.id || '1',
          hospitalId: appointment.hospitalId,
          date: new Date(),
          status: 'created',
          medicines: prescriptionMedicines.map((med, index) => ({
            id: index.toString(),
            ...med,
            status: 'pending'
          })),
          instructions: visitData.plan
        };

        addPrescription(prescription);
      }

      // Update appointment status
      updateAppointment(appointment.id, { status: 'completed' });

      onClose();
    } finally {
      setIsLoading(false);
    }
  };

  if (!patient) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-2xl max-w-6xl w-full mx-4 max-h-[95vh] overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
              <User className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">{patient.name}</h2>
              <div className="flex items-center space-x-4 text-sm text-gray-500">
                <span>{patient.phone}</span>
                <span>{patient.age}y • {patient.sex}</span>
                <div className="flex items-center space-x-1">
                  <Calendar className="h-4 w-4" />
                  <span>{new Date(appointment.date).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Patient Tags & Allergies */}
        {(patient.tags.length > 0 || patient.allergies && patient.allergies.length > 0) && (
          <div className="px-6 py-3 bg-orange-50 border-b border-orange-200">
            <div className="flex items-center space-x-4">
              {patient.allergies && patient.allergies.length > 0 && (
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-medium text-orange-800">Allergies:</span>
                  <div className="flex space-x-1">
                    {patient.allergies.map((allergy, index) => (
                      <span key={index} className="text-xs bg-red-100 text-red-800 px-2 py-1 rounded-full">
                        {allergy}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              {patient.tags.length > 0 && (
                <div className="flex space-x-1">
                  {patient.tags.map((tag, index) => (
                    <span key={index} className="text-xs bg-orange-100 text-orange-800 px-2 py-1 rounded-full">
                      {tag.label}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="border-b border-gray-200">
          <nav className="px-6 flex space-x-8">
            {[
              { key: 'consultation', label: 'Consultation', icon: FileText },
              { key: 'history', label: 'Patient History', icon: Calendar },
              { key: 'prescription', label: 'Prescription', icon: Pill }
            ].map(tab => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm ${
                  activeTab === tab.key
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <tab.icon className="h-4 w-4" />
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto max-h-[60vh]">
          {activeTab === 'consultation' && (
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Subjective (Patient's Complaint)
                  </label>
                  <textarea
                    rows={4}
                    value={visitData.subjective}
                    onChange={(e) => setVisitData(prev => ({ ...prev, subjective: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Patient's chief complaint and symptoms..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Objective (Clinical Findings)
                  </label>
                  <textarea
                    rows={4}
                    value={visitData.objective}
                    onChange={(e) => setVisitData(prev => ({ ...prev, objective: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Physical examination findings, vitals, test results..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Assessment (Diagnosis)
                  </label>
                  <textarea
                    rows={4}
                    value={visitData.assessment}
                    onChange={(e) => setVisitData(prev => ({ ...prev, assessment: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Primary and secondary diagnoses..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Plan (Treatment Plan)
                  </label>
                  <textarea
                    rows={4}
                    value={visitData.plan}
                    onChange={(e) => setVisitData(prev => ({ ...prev, plan: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Treatment plan, follow-up instructions..."
                  />
                </div>
              </div>

              <div>
                <label className="flex items-center space-x-2 text-sm font-medium text-gray-700 mb-2">
                  <span>Clinical Notes (Private)</span>
                  <span className="text-xs bg-red-100 text-red-600 px-2 py-1 rounded-full">Private to you</span>
                </label>
                <textarea
                  rows={3}
                  value={visitData.clinicalNotes}
                  onChange={(e) => setVisitData(prev => ({ ...prev, clinicalNotes: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Private clinical notes, differential diagnosis, concerns..."
                />
              </div>
            </div>
          )}

          {activeTab === 'history' && (
            <div className="p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Patient History</h3>
              {patientHistory.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Calendar className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                  <p>No previous visits found</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {patientHistory.map(visit => (
                    <div key={visit.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{new Date(visit.date).toLocaleDateString()}</span>
                        <span className="text-sm text-gray-500">Dr. {user?.name}</span>
                      </div>
                      {visit.assessment && (
                        <p className="text-sm text-gray-700 mb-2"><strong>Diagnosis:</strong> {visit.assessment}</p>
                      )}
                      {visit.plan && (
                        <p className="text-sm text-gray-700"><strong>Treatment:</strong> {visit.plan}</p>
                      )}
                      {/* Clinical notes only visible to the authoring doctor */}
                      {visit.clinicalNotes && visit.doctorId === user?.id && (
                        <p className="text-sm text-gray-600 mt-2 p-2 bg-gray-50 rounded">
                          <strong>Private Notes:</strong> {visit.clinicalNotes}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'prescription' && (
            <div className="p-6 space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-gray-900">Prescription</h3>
                <button
                  onClick={() => setShowAddMedicine(true)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm font-medium"
                >
                  Add Medicine
                </button>
              </div>

              {showAddMedicine && (
                <div className="border border-gray-300 rounded-lg p-4 bg-gray-50">
                  <h4 className="font-medium text-gray-900 mb-4">Add Medicine</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Medicine Name *</label>
                      <input
                        type="text"
                        value={newMedicine.name}
                        onChange={(e) => setNewMedicine(prev => ({ ...prev, name: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                        placeholder="Paracetamol"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Dose *</label>
                      <input
                        type="text"
                        value={newMedicine.dose}
                        onChange={(e) => setNewMedicine(prev => ({ ...prev, dose: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                        placeholder="500mg"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Frequency *</label>
                      <input
                        type="text"
                        value={newMedicine.frequency}
                        onChange={(e) => setNewMedicine(prev => ({ ...prev, frequency: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                        placeholder="1-1-1 or 2 times daily"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Route</label>
                      <select
                        value={newMedicine.route}
                        onChange={(e) => setNewMedicine(prev => ({ ...prev, route: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                      >
                        <option value="Oral">Oral</option>
                        <option value="IV">IV</option>
                        <option value="IM">IM</option>
                        <option value="Topical">Topical</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Duration (days)</label>
                      <input
                        type="number"
                        value={newMedicine.duration}
                        onChange={(e) => setNewMedicine(prev => ({ ...prev, duration: parseInt(e.target.value) }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Instructions</label>
                      <input
                        type="text"
                        value={newMedicine.instructions}
                        onChange={(e) => setNewMedicine(prev => ({ ...prev, instructions: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                        placeholder="After food"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end space-x-2 mt-4">
                    <button
                      onClick={() => setShowAddMedicine(false)}
                      className="px-3 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 text-sm"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={addMedicine}
                      className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm"
                    >
                      Add Medicine
                    </button>
                  </div>
                </div>
              )}

              <div className="space-y-3">
                {prescriptionMedicines.map((medicine, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4 flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-4">
                        <div>
                          <p className="font-medium text-gray-900">{medicine.name}</p>
                          <p className="text-sm text-gray-500">
                            {medicine.dose} • {medicine.frequency} • {medicine.route} • {medicine.duration} days
                          </p>
                          {medicine.instructions && (
                            <p className="text-sm text-blue-600">{medicine.instructions}</p>
                          )}
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => removeMedicine(index)}
                      className="text-red-600 hover:text-red-700 text-sm"
                    >
                      Remove
                    </button>
                  </div>
                ))}

                {prescriptionMedicines.length === 0 && !showAddMedicine && (
                  <div className="text-center py-8 text-gray-500">
                    <Pill className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                    <p>No medicines added to prescription</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-200 flex justify-end space-x-3">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 font-medium"
          >
            Cancel
          </button>
          <button
            onClick={handleCompleteVisit}
            disabled={isLoading}
            className="flex items-center space-x-2 px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium disabled:opacity-50"
          >
            <Send className="h-4 w-4" />
            <span>{isLoading ? 'Completing...' : 'Complete Visit'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}