import React, { useState } from 'react';
import { Package, Clock, CheckCircle, XCircle, FileText, Search } from 'lucide-react';
import { useData } from '../../contexts/DataContext';
import StatusBadge from '../common/StatusBadge';

export default function PharmacyDashboard() {
  const { prescriptions, patients } = useData();
  const [selectedFilter, setSelectedFilter] = useState('all');

  const stats = [
    { 
      label: 'New Prescriptions', 
      value: prescriptions.filter(p => p.status === 'created').length, 
      icon: Package, 
      color: 'text-blue-600',
      bg: 'bg-blue-100' 
    },
    { 
      label: 'In Progress', 
      value: prescriptions.filter(p => p.status === 'partially-dispensed').length, 
      icon: Clock, 
      color: 'text-orange-600',
      bg: 'bg-orange-100' 
    },
    { 
      label: 'Completed', 
      value: prescriptions.filter(p => p.status === 'fully-dispensed').length, 
      icon: CheckCircle, 
      color: 'text-green-600',
      bg: 'bg-green-100' 
    },
    { 
      label: 'Not Available', 
      value: prescriptions.filter(p => p.status === 'not-available').length, 
      icon: XCircle, 
      color: 'text-red-600',
      bg: 'bg-red-100' 
    }
  ];

  const getPatientName = (patientId: string) => {
    const patient = patients.find(p => p.id === patientId);
    return patient?.name || 'Unknown Patient';
  };

  const getPatientPhone = (patientId: string) => {
    const patient = patients.find(p => p.id === patientId);
    return patient?.phone || 'Unknown';
  };

  const getDoctorName = (doctorId: string) => {
    const doctors = [
      { id: '1', name: 'Dr. Sarah Johnson' },
      { id: '2', name: 'Dr. Michael Chen' },
      { id: '3', name: 'Dr. Emily Davis' }
    ];
    const doctor = doctors.find(d => d.id === doctorId);
    return doctor?.name || 'Unknown Doctor';
  };

  const filteredPrescriptions = selectedFilter === 'all' 
    ? prescriptions 
    : prescriptions.filter(p => p.status === selectedFilter);

  const sortedPrescriptions = [...filteredPrescriptions].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Pharmacy Dashboard</h1>
        <p className="text-gray-600">Prescription management and dispensing</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                <p className="text-2xl font-bold text-gray-900 mt-2">{stat.value}</p>
              </div>
              <div className={`${stat.bg} p-3 rounded-lg`}>
                <stat.icon className={`h-6 w-6 ${stat.color}`} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Prescription Queue */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-gray-900">Prescription Queue</h2>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search by phone or name..."
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div className="flex space-x-2">
              {[
                { key: 'all', label: 'All' },
                { key: 'created', label: 'New' },
                { key: 'partially-dispensed', label: 'In Progress' },
                { key: 'fully-dispensed', label: 'Completed' },
                { key: 'not-available', label: 'Not Available' }
              ].map(filter => (
                <button
                  key={filter.key}
                  onClick={() => setSelectedFilter(filter.key)}
                  className={`px-3 py-1 text-xs rounded-full font-medium ${
                    selectedFilter === filter.key
                      ? 'bg-blue-100 text-blue-600'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {filter.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-4">
          {sortedPrescriptions.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <FileText className="h-12 w-12 text-gray-300 mx-auto mb-3" />
              <p>No prescriptions found</p>
            </div>
          ) : (
            sortedPrescriptions.map((prescription) => (
              <div key={prescription.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 cursor-pointer">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-4">
                    <div>
                      <p className="font-medium text-gray-900">{getPatientName(prescription.patientId)}</p>
                      <p className="text-sm text-gray-500">{getPatientPhone(prescription.patientId)}</p>
                    </div>
                    <div className="text-sm text-gray-500">
                      <p>Dr. {getDoctorName(prescription.doctorId)}</p>
                      <p>{new Date(prescription.date).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <StatusBadge status={prescription.status} type="prescription" />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                  {prescription.medicines.slice(0, 3).map((medicine, index) => (
                    <div key={index} className="text-sm bg-gray-50 rounded p-2">
                      <p className="font-medium">{medicine.name}</p>
                      <p className="text-gray-500">{medicine.dose} • {medicine.frequency}</p>
                    </div>
                  ))}
                  {prescription.medicines.length > 3 && (
                    <div className="text-sm bg-gray-50 rounded p-2 flex items-center justify-center text-gray-500">
                      +{prescription.medicines.length - 3} more
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}