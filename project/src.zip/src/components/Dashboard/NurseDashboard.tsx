import React, { useState } from 'react';
import { Calendar, UserPlus, Users, Clock, User } from 'lucide-react';
import { useData } from '../../contexts/DataContext';
import { useAuth } from '../../contexts/AuthContext';
import StatusBadge from '../common/StatusBadge';
import AppointmentForm from '../Forms/AppointmentForm';
import { Appointment, User } from '../../types';


export default function NurseDashboard() {
  const { getTodaysAppointments, patients } = useData();
  const { user } = useAuth();
  const [showAppointmentForm, setShowAppointmentForm] = useState(false);

  const todaysAppointments = getTodaysAppointments();

  const stats = [
    { 
      label: "Today's Appointments", 
      value: todaysAppointments.length, 
      icon: Calendar, 
      color: 'text-blue-600',
      bg: 'bg-blue-100' 
    },
    { 
      label: 'Registered Patients', 
      value: patients.length, 
      icon: Users, 
      color: 'text-green-600',
      bg: 'bg-green-100' 
    },
    { 
      label: 'Completed Today', 
      value: todaysAppointments.filter(a => a.status === 'completed').length, 
      icon: UserPlus, 
      color: 'text-purple-600',
      bg: 'bg-purple-100' 
    },
    { 
      label: 'Pending', 
      value: todaysAppointments.filter(a => a.status === 'scheduled').length, 
      icon: Clock, 
      color: 'text-orange-600',
      bg: 'bg-orange-100' 
    }
  ];

  const getPatientName = (patientId: string) => {
    const patient = patients.find(p => p.id === patientId);
    return patient?.name || 'Unknown Patient';
  };

  const getDoctorName = (doctorId: string) => {
    const doctors = [
      { id: '1', name: 'Dr. Sarah Johnson' },
      { id: '2', name: 'Dr. Michael Chen' },
      { id: '3', name: 'Dr. Emily Davis' }
    ];
    const doctor = doctors.find(d => d.id === doctorId);
    return doctor?.name || 'Unknown Doctor';
  };

  return (
    <>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Nurse Dashboard</h1>
          <p className="text-gray-600">Patient coordination and appointment management</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-lg border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-2">{stat.value}</p>
                </div>
                <div className={`${stat.bg} p-3 rounded-lg`}>
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <button 
              onClick={() => setShowAppointmentForm(true)}
              className="flex items-center space-x-3 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <Calendar className="h-5 w-5 text-blue-600" />
              <span className="font-medium">Create Appointment</span>
            </button>
            <button className="flex items-center space-x-3 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <UserPlus className="h-5 w-5 text-green-600" />
              <span className="font-medium">Register Patient</span>
            </button>
          </div>
        </div>

        {/* Today's Schedule by Doctor */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Today's Schedule by Doctor</h2>
          
          <div className="space-y-6">
            {['1', '2', '3'].map(doctorId => {
              const doctorAppointments = todaysAppointments.filter(a => a.doctorId === doctorId);
              
              return (
                <div key={doctorId} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-medium text-gray-900">{getDoctorName(doctorId)}</h3>
                    <span className="text-sm text-gray-500">{doctorAppointments.length} appointments</span>
                  </div>
                  
                  <div className="space-y-2">
                    {doctorAppointments.length === 0 ? (
                      <p className="text-sm text-gray-500 text-center py-4">No appointments today</p>
                    ) : (
                      doctorAppointments.map(appointment => (
                        <div key={appointment.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <div className="flex items-center space-x-1 text-sm text-gray-500">
                              <Clock className="h-4 w-4" />
                              <span>{appointment.timeSlot}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <User className="h-4 w-4 text-gray-400" />
                              <span className="font-medium">{getPatientName(appointment.patientId)}</span>
                            </div>
                          </div>
                          <StatusBadge status={appointment.status} type="appointment" size="sm" />
                        </div>
                      ))
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {showAppointmentForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900">Create New Appointment</h2>
            </div>
            <div className="p-6">
              <AppointmentForm
                onSubmit={() => setShowAppointmentForm(false)}
                onCancel={() => setShowAppointmentForm(false)}
              />
            </div>
          </div>
        </div>
      )}
    </>
  );
}