import React, { useState } from 'react';
import { Calendar, Clock, User, FileText, Activity, Play } from 'lucide-react';
import { useData } from '../../contexts/DataContext';
import { useAuth } from '../../contexts/AuthContext';
import StatusBadge from '../Common/StatusBadge';
import ConsultationModal from '../Consultation/ConsultationModal';

export default function DoctorDashboard() {
  const { getTodaysAppointments, patients, prescriptions } = useData();
  const { user } = useAuth();
  const [selectedAppointment, setSelectedAppointment] = useState<any>(null);
  const [showConsultation, setShowConsultation] = useState(false);

  const todaysAppointments = getTodaysAppointments(user?.id);
  const myPrescriptions = prescriptions.filter(p => p.doctorId === user?.id);

  const stats = [
    { 
      label: "Today's Appointments", 
      value: todaysAppointments.length, 
      icon: Calendar, 
      color: 'text-blue-600',
      bg: 'bg-blue-100' 
    },
    { 
      label: 'Completed Today', 
      value: todaysAppointments.filter(a => a.status === 'completed').length, 
      icon: FileText, 
      color: 'text-green-600',
      bg: 'bg-green-100' 
    },
    { 
      label: 'In Progress', 
      value: todaysAppointments.filter(a => a.status === 'in-consultation').length, 
      icon: Activity, 
      color: 'text-orange-600',
      bg: 'bg-orange-100' 
    },
    { 
      label: 'Prescriptions', 
      value: myPrescriptions.length, 
      icon: FileText, 
      color: 'text-purple-600',
      bg: 'bg-purple-100' 
    }
  ];

  const handleStartConsultation = (appointment: any) => {
    setSelectedAppointment(appointment);
    setShowConsultation(true);
  };

  const getPatientName = (patientId: string) => {
    const patient = patients.find(p => p.id === patientId);
    return patient?.name || 'Unknown Patient';
  };

  return (
    <>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-gray-900">My Practice</h1>
          <p className="text-gray-600">Today's schedule and consultations</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-lg border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-2">{stat.value}</p>
                </div>
                <div className={`${stat.bg} p-3 rounded-lg`}>
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Today's Appointments */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-900">Today's Appointments</h2>
            <div className="flex space-x-2">
              <button className="px-3 py-1 text-xs bg-gray-100 text-gray-600 rounded-full">All</button>
              <button className="px-3 py-1 text-xs bg-blue-100 text-blue-600 rounded-full">Scheduled</button>
              <button className="px-3 py-1 text-xs bg-green-100 text-green-600 rounded-full">Completed</button>
            </div>
          </div>

          <div className="space-y-4">
            {todaysAppointments.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Calendar className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                <p>No appointments scheduled for today</p>
              </div>
            ) : (
              todaysAppointments.map((appointment) => (
                <div key={appointment.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2 text-sm text-gray-500">
                      <Clock className="h-4 w-4" />
                      <span>{appointment.timeSlot}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <User className="h-4 w-4 text-gray-400" />
                      <span className="font-medium">{getPatientName(appointment.patientId)}</span>
                    </div>
                    <StatusBadge status={appointment.status} type="appointment" size="sm" />
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    {appointment.purpose && (
                      <span className="text-sm text-gray-500">{appointment.purpose}</span>
                    )}
                    {appointment.status === 'scheduled' && (
                      <button
                        onClick={() => handleStartConsultation(appointment)}
                        className="flex items-center space-x-1 px-3 py-1 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700"
                      >
                        <Play className="h-3 w-3" />
                        <span>Start</span>
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Recent Prescriptions Status */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Recent Prescription Status</h2>
          <div className="space-y-3">
            {myPrescriptions.slice(0, 5).map((prescription) => (
              <div key={prescription.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium">{getPatientName(prescription.patientId)}</p>
                  <p className="text-sm text-gray-500">{new Date(prescription.date).toLocaleDateString()}</p>
                </div>
                <StatusBadge status={prescription.status} type="prescription" size="sm" />
              </div>
            ))}
            {myPrescriptions.length === 0 && (
              <div className="text-center py-4 text-gray-500">
                <FileText className="h-8 w-8 text-gray-300 mx-auto mb-2" />
                <p>No prescriptions yet</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {showConsultation && selectedAppointment && (
        <ConsultationModal
          appointment={selectedAppointment}
          onClose={() => {
            setShowConsultation(false);
            setSelectedAppointment(null);
          }}
        />
      )}
    </>
  );
}