import { useState } from 'react';
import { Users, Calendar, Activity, UserCheck, Stethoscope, ShoppingBag } from 'lucide-react';
import { useData } from '../../contexts/DataContext';
import AddUserModal from '../../pages/admin/Admin_Pages/AddUserModal'; // Adjust this path if your modal is elsewhere

// Define the possible roles for clarity and type safety
type UserRole = 'doctor' | 'nurse' | 'medical_shop';

export default function AdminDashboard() {
  const { appointments, prescriptions } = useData();
  
  // --- STATE FOR MODAL ---
  // Manages whether the "Add User" modal is visible or not
  const [isModalOpen, setIsModalOpen] = useState(false);
  // Stores which role we are adding ('doctor', 'nurse', etc.) to pass to the modal
  const [userRoleToAdd, setUserRoleToAdd] = useState<UserRole | null>(null);

  // --- HANDLERS FOR MODAL ---
  /**
   * Opens the modal and sets the role of the user to be created.
   * @param role The role to add, e.g., 'doctor'
   */
  const handleOpenModal = (role: UserRole) => {
    setUserRoleToAdd(role);
    setIsModalOpen(true);
  };

  /**
   * Closes the modal and resets the role state.
   */
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setUserRoleToAdd(null);
    // Optional: After a user is added, you might want to trigger a data refresh here.
  };

  // --- DATA COMPUTATIONS ---
  const todaysAppointments = appointments.filter(apt => {
    const today = new Date();
    const appointmentDate = new Date(apt.date);
    return appointmentDate.toDateString() === today.toDateString();
  });

  const activeDoctors = 4; // Mock data
  const pendingDispenses = prescriptions.filter(p => p.status === 'created' || p.status === 'partially-dispensed').length;

  const stats = [
    { 
      label: "Today's Appointments", 
      value: todaysAppointments.length, 
      icon: Calendar, 
      color: 'text-blue-600',
      bg: 'bg-blue-100' 
    },
    { 
      label: 'Active Doctors', 
      value: activeDoctors, 
      icon: Stethoscope, 
      color: 'text-green-600',
      bg: 'bg-green-100' 
    },
    { 
      label: 'Pending Pharmacy', 
      value: pendingDispenses, 
      icon: ShoppingBag, 
      color: 'text-orange-600',
      bg: 'bg-orange-100' 
    },
    { 
      label: 'Active Nurses', 
      value: 8, 
      icon: UserCheck, 
      color: 'text-purple-600',
      bg: 'bg-purple-100' 
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
        <p className="text-gray-600">Hospital management overview</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                <p className="text-2xl font-bold text-gray-900 mt-2">{stat.value}</p>
              </div>
              <div className={`${stat.bg} p-3 rounded-lg`}>
                <stat.icon className={`h-6 w-6 ${stat.color}`} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button 
            onClick={() => handleOpenModal('doctor')}
            className="flex items-center space-x-3 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <Users className="h-5 w-5 text-blue-600" />
            <span className="font-medium">Add Doctor</span>
          </button>
          <button 
            onClick={() => handleOpenModal('nurse')}
            className="flex items-center space-x-3 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <UserCheck className="h-5 w-5 text-green-600" />
            <span className="font-medium">Add Nurse</span>
          </button>
          <button 
            onClick={() => handleOpenModal('medical_shop')}
            className="flex items-center space-x-3 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <ShoppingBag className="h-5 w-5 text-orange-600" />
            <span className="font-medium">Add Medical Shop</span>
          </button>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h2>
        <div className="space-y-4">
          <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
            <Activity className="h-5 w-5 text-blue-600" />
            <div>
              <p className="text-sm font-medium">New appointment created</p>
              <p className="text-xs text-gray-500">John Smith with Dr. Johnson • 10 minutes ago</p>
            </div>
          </div>
          <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
            <Activity className="h-5 w-5 text-green-600" />
            <div>
              <p className="text-sm font-medium">Prescription dispensed</p>
              <p className="text-xs text-gray-500">Mary Johnson • 25 minutes ago</p>
            </div>
          </div>
          <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
            <Activity className="h-5 w-5 text-orange-600" />
            <div>
              <p className="text-sm font-medium">New patient registered</p>
              <p className="text-xs text-gray-500">Alice Brown • 1 hour ago</p>
            </div>
          </div>
        </div>
      </div>

      {/* 
        This is where the modal is rendered. 
        It's hidden by default and only appears when `isModalOpen` is true.
      */}
      <AddUserModal 
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        role={userRoleToAdd}
      />
    </div>
  );
}