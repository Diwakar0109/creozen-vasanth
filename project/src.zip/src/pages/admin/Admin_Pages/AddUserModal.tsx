import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';

// Define the shape of the form data
interface UserFormData {
  email: string;
  full_name: string;
  password: string;
}

// Define the props for our component
interface AddUserModalProps {
  isOpen: boolean;
  onClose: () => void;
  // The role is passed to determine what kind of user we are adding
  role: 'doctor' | 'nurse' | 'medical_shop' | null; 
}

// A helper function to capitalize the first letter
const capitalize = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

const AddUserModal: React.FC<AddUserModalProps> = ({ isOpen, onClose, role }) => {
  const initialState: UserFormData = {
    email: '',
    full_name: '',
    password: '',
  };

  const [formData, setFormData] = useState<UserFormData>(initialState);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Reset form state when the modal is closed or the role changes
  useEffect(() => {
    if (!isOpen) {
      setFormData(initialState);
      setError(null);
      setSuccess(null);
      setIsLoading(false);
    }
  }, [isOpen]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!role) return;

    setIsLoading(true);
    setError(null);
    setSuccess(null);

    // This is the API endpoint for creating users.
    // NOTE: This is an assumption. Please change '/api/users/' if your endpoint is different.
    const API_URL = 'http://127.0.0.1:8000/api/users/';

    // IMPORTANT: You need a way to get the admin's auth token.
    // Usually, it's stored in localStorage or a context after login.
    const token = localStorage.getItem('authToken'); 

    if (!token) {
        setError('Authentication error. Please log in again.');
        setIsLoading(false);
        return;
    }

    try {
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}` // Sending the token for authorization
        },
        body: JSON.stringify({
          ...formData,
          role: role, // The role is determined by which button was clicked
          is_active: true, // As per your schema
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        // Handle backend validation errors (e.g., email already exists)
        const errorMessage = data.detail || 'An unexpected error occurred.';
        throw new Error(errorMessage);
      }

      setSuccess(`Successfully created ${role.replace('_', ' ')}: ${formData.full_name}`);
      setFormData(initialState); // Clear the form on success
      
      // Optionally, close the modal after a short delay
      setTimeout(() => {
        onClose();
      }, 2000);

    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Don't render anything if the modal is not open
  if (!isOpen || !role) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-800">Add New {capitalize(role.replace('_', ' '))}</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-800">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="full_name" className="block text-sm font-medium text-gray-700">Full Name</label>
            <input
              type="text"
              id="full_name"
              name="full_name"
              value={formData.full_name}
              onChange={handleChange}
              required
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email Address</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-700">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              required
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          {error && <p className="text-sm text-red-600 bg-red-100 p-2 rounded-md">{error}</p>}
          {success && <p className="text-sm text-green-600 bg-green-100 p-2 rounded-md">{success}</p>}

          <div className="flex justify-end space-x-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              disabled={isLoading}
              className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-blue-300 flex items-center"
            >
              {isLoading ? 'Creating...' : 'Create User'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddUserModal;