// src/types/index.ts

// USER & PATIENT TYPES
export type UserRole = 'admin' | 'doctor' | 'nurse' | 'medical_shop';

export interface User {
  id: number;
  full_name: string;
  email: string;
  is_active: boolean;
  role: UserRole;
  hospital_id: number;
}

export interface Patient {
  id: number;
  full_name: string;
  phone_number: string;
  date_of_birth: string | null;
  sex: string | null;
  // These are from your old modal, keep them if you need them
  tags?: any[];
  allergies?: string[];
}

// PRESCRIPTION TYPES
export type PrescriptionRecordStatus = 'Created' | 'Partially Dispensed' | 'Fully Dispensed' | 'Not Available';
export type PrescriptionLineItemStatus = 'Given' | 'Partially Given' | 'Not Given' | 'Substituted';

export interface PrescriptionLineItem {
    id: number;
    medicine_name: string;
    dose: string | null;
    frequency: string | null;
    duration_days: number | null;
    instructions: string | null;
    status: PrescriptionLineItemStatus;
    substitution_info: string | null;
}

export interface PrescriptionRecord {
  id: number;
  status: PrescriptionRecordStatus;
  patient_id: number;
  doctor_id: number;
  visit_id: number;
  line_items: PrescriptionLineItem[];
}

// VISIT & APPOINTMENT TYPES
export interface Visit {
  id: number;
  diagnosis_summary: string | null;
  subjective: string | null;
  objective: string | null;
  assessment: string | null;
  plan: string | null;
  // --- CORRECTED PROPERTY NAME ---
  prescription?: PrescriptionRecord | null;
}

export interface Appointment {
  id: number;
  appointment_time: string;
  visit_purpose: string | null;
  status: 'Scheduled' | 'In-Consultation' | 'Completed' | 'No-Show' | 'Cancelled';
  patient: Patient;
  doctor: User;
  hospital_id: number;
  visit?: Visit | null;
}