import enum
from sqlalchemy import (
    Column,
    Integer,
    String,
    DateTime,
    Enum,
    ForeignKey,
    func
)
from sqlalchemy.orm import relationship

from app.db.base_class import Base

# Define the Enums for database status values
class PrescriptionStatus(str, enum.Enum):
    CREATED = "Created"
    PARTIALLY_DISPENSED = "Partially Dispensed"
    FULLY_DISPENSED = "Fully Dispensed"
    NOT_AVAILABLE = "Not Available"

class DispenseLineStatus(str, enum.Enum):
    GIVEN = "Given"
    PARTIALLY_GIVEN = "Partially Given"
    NOT_GIVEN = "Not Given"
    SUBSTITUTED = "Substituted"


# Define the parent Prescription table
class Prescription(Base):
    __tablename__ = 'prescriptions'

    id = Column(Integer, primary_key=True, index=True)
    status = Column(Enum(PrescriptionStatus), default=PrescriptionStatus.CREATED, nullable=False)
    
    visit_id = Column(Integer, ForeignKey("visits.id"))
    patient_id = Column(Integer, ForeignKey("patients.id"))
    doctor_id = Column(Integer, ForeignKey("users.id"))
    
    created_at = Column(DateTime, default=func.now(), nullable=False)
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now(), nullable=False)
    
    # This defines the relationship to the child objects (the line items)
    # 'back_populates' links it to the 'prescription' attribute in the PrescriptionLineItem class
    line_items = relationship(
        "PrescriptionLineItem", 
        back_populates="prescription", 
        cascade="all, delete-orphan"
    )
    
    # These define relationships to other parent objects
    # NOTE: Your other model files (patient.py, visit.py) must have the corresponding back_populates
    patient = relationship("Patient", back_populates="prescriptions")
    visit = relationship("Visit", back_populates="prescription")
    doctor = relationship("User")


# Define the child PrescriptionLineItem table
class PrescriptionLineItem(Base):
    __tablename__ = 'prescriptionlineitems'

    id = Column(Integer, primary_key=True, index=True)
    
    medicine_name = Column(String, nullable=False)
    dose = Column(String, nullable=True)
    frequency = Column(String, nullable=True)
    duration_days = Column(Integer, nullable=True)
    instructions = Column(String, nullable=True)
    status = Column(Enum(DispenseLineStatus), default=DispenseLineStatus.NOT_GIVEN, nullable=False)
    substitution_info = Column(String, nullable=True)
    
    # This is the foreign key that links a line item back to its parent Prescription
    prescription_id = Column(Integer, ForeignKey("prescriptions.id"))
    
    # This defines the relationship back to the parent object
    # 'back_populates' links it to the 'line_items' attribute in the Prescription class
    prescription = relationship("Prescription", back_populates="line_items")