from sqlalchemy import Column, Integer, String, Date, Enum as PyEnum
from sqlalchemy.orm import relationship
from app.db.base_class import Base

class Patient(Base):
    id = Column(Integer, primary_key=True, index=True)
    full_name = Column(String, nullable=False, index=True)
    phone_number = Column(String, nullable=False, index=True)
    
    # Optional demographics
    date_of_birth = Column(Date, nullable=True)
    sex = Column(String, nullable=True)
    
    # Relationships
    appointments = relationship("Appointment", back_populates="patient", cascade="all, delete-orphan")
    prescriptions = relationship("Prescription", back_populates="patient")