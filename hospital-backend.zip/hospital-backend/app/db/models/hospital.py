from sqlalchemy import Column, Integer, String, JSON
from sqlalchemy.orm import relationship
from app.db.base_class import Base

class Hospital(Base):
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False, unique=True)
    
    # Use JSON for flexible settings like branding, hours, etc.
    settings = Column(JSON, nullable=True)
    
    # A hospital has many users
    users = relationship("User", back_populates="hospital")