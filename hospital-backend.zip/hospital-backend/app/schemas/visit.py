# In app/schemas/visit.py

from pydantic import BaseModel
from typing import Optional, List

# --- Import schemas that will be nested inside our payload ---
from .prescription import Prescription, PrescriptionCreate
from .user import User

# --- Base Schemas and Response Schemas ---

class ClinicalNote(BaseModel):
    id: int
    content: str
    author_doctor: User # Assuming you want to show who wrote the note

    class Config:
        from_attributes = True # Updated from orm_mode

class VisitBase(BaseModel):
    diagnosis_summary: Optional[str] = None
    subjective: Optional[str] = None
    objective: Optional[str] = None
    assessment: Optional[str] = None
    plan: Optional[str] = None

class VisitForStaff(VisitBase):
    id: int
    class Config:
        from_attributes = True

class VisitForDoctor(VisitBase):
    id: int
    authored_notes: List[ClinicalNote] = []
    prescription: Optional[Prescription] = None

    class Config:
        from_attributes = True

# --- Schemas for Creating/Updating Data ---

class VisitCreate(VisitBase):
    private_note: Optional[str] = None

class ClinicalNoteCreate(BaseModel):
    content: str

# --- THIS IS THE MISSING CLASS THAT CAUSED THE CRASH ---
# This schema defines the structure of the JSON payload that the frontend
# sends when a doctor clicks the "Complete Visit" button.
class CompleteVisitPayload(BaseModel):
    visit_details: VisitCreate
    prescription_details: Optional[PrescriptionCreate] = None