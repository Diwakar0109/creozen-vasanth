# In app/schemas/appointment.py

from pydantic import BaseModel
from datetime import datetime
from typing import Optional

# --- Import all necessary components ---
from ..db.models.appointment import AppointmentStatus
from .patient import Patient
from .user import User
# --- THIS IS THE CRITICAL IMPORT ---
from .visit import VisitForDoctor

# Schema for creating a new appointment
class AppointmentCreate(BaseModel):
    patient_id: int
    doctor_id: int
    appointment_time: datetime
    visit_purpose: Optional[str] = None

# Schema for updating an appointment
class AppointmentUpdate(BaseModel):
    pass # Define fields that can be updated if any

# --- THIS IS THE SCHEMA THAT FIXES THE PROBLEM ---
# This is the main schema used for API responses (like in read_appointments)
class Appointment(BaseModel):
    id: int
    appointment_time: datetime
    status: AppointmentStatus
    visit_purpose: Optional[str] = None

    # These relationships should already be defined
    patient: Patient
    doctor: User

    # --- THIS IS THE CRITICAL FIX ---
    # This line tells Pydantic to look for the 'visit' relationship
    # on the SQLAlchemy model and include it in the JSON response,
    # using the 'VisitForDoctor' schema as its blueprint.
    visit: Optional[VisitForDoctor] = None

    class Config:
        from_attributes = True # This must be True to read from database models