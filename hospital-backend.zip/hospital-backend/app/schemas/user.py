from pydantic import BaseModel, EmailStr
from typing import Optional
from app.db.models.user import UserRole

class UserBase(BaseModel):
    email: Optional[EmailStr] = None
    full_name: Optional[str] = None
    is_active: Optional[bool] = True

class UserCreate(UserBase):
    email: EmailStr
    password: str
    full_name: str
    role: UserRole
    hospital_id: Optional[int] = None # <-- ADD


class UserUpdate(UserBase):
    password: Optional[str] = None

class User(UserBase):
    id: int
    role: UserRole
    hospital_id: Optional[int] = None # <-- ADD


    class Config:
        from_attributes  = True