# Create this new file at: app/schemas/token.py

from pydantic import BaseModel
from typing import Optional
from app.db.models.user import UserRole

class Token(BaseModel):
    access_token: str
    token_type: str

from pydantic import EmailStr

class TokenPayload(BaseModel):
    sub: Optional[EmailStr] = None