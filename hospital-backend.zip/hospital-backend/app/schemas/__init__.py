# app/schemas/__init__.py (CORRECTED & FINAL)

# This makes the Token class available directly from the 'schemas' module
from .token import Token, TokenPayload

# Do the same for all your other schemas
from .user import User, UserCreate, UserUpdate
from .patient import Patient, PatientCreate, PatientUpdate, PatientLookup
from .appointment import Appointment, AppointmentCreate, AppointmentUpdate
# NEW - Corrected line
from .visit import VisitForStaff, VisitForDoctor, VisitCreate, ClinicalNote, ClinicalNoteCreate
from .prescription import (
    Prescription,
    PrescriptionCreate,
    PrescriptionLineItem,
    PrescriptionLineItemCreate,
    DispenseUpdate,
)
from .msg import Msg
from .hospital import Hospital, HospitalCreate, HospitalUpdate
from .audit import AuditLog, AuditLogCreate
from .visit import CompleteVisitPayload
from .prescription import Prescription, DispenseUpdate, PharmacyStats

