from pydantic import BaseModel, Field
from typing import Optional, List
from app.db.models.prescription import PrescriptionStatus, DispenseLineStatus
from .patient import Patient # <--- 1. IMPORT the Patient schema


class PrescriptionLineItemBase(BaseModel):
    medicine_name: str
    dose: Optional[str]
    frequency: Optional[str]
    duration_days: Optional[int]
    instructions: Optional[str]

class PrescriptionLineItemCreate(PrescriptionLineItemBase):
    pass

class PrescriptionLineItem(PrescriptionLineItemBase):
    id: int
    status: DispenseLineStatus
    substitution_info: Optional[str]

    class Config:
        from_attributes  = True

# For the doctor to create a full prescription
class PrescriptionCreate(BaseModel):
    line_items: List[PrescriptionLineItemCreate]

# For the pharmacy to update dispense status
class DispenseUpdate(BaseModel):
    line_item_id: int
    status: DispenseLineStatus
    substitution_info: Optional[str] = None

# Full Prescription schema for responses
class Prescription(BaseModel):
    id: int
    status: PrescriptionStatus
    patient_id: int
    doctor_id: int
    visit_id: int
    line_items: List[PrescriptionLineItem]
    patient: Patient

    class Config:
        from_attributes  = True



# In app/schemas/prescription.py
from pydantic import BaseModel

# ... (keep all your existing schemas) ...

# --- ADD THIS NEW SCHEMA AT THE END OF THE FILE ---
class PharmacyStats(BaseModel):
    new_prescriptions: int
    in_progress: int
    completed_today: int
    total_pending: int