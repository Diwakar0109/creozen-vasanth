from .crud_user import user
from .crud_patient import patient
from .crud_appointment import appointment
from .crud_prescription import prescription
from .crud_hospital import hospital # <-- ADD
from .crud_audit import audit_log # <-- ADD