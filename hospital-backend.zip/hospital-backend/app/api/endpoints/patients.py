from typing import List, Any
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import date, datetime
from fastapi import Query # <--- Make sure to import Query
from sqlalchemy import select
from app.db import models

from app import schemas, crud, db
from app.api import deps

router = APIRouter()

@router.post(
    "/",
    response_model=schemas.Patient,
    dependencies=[Depends(deps.require_role([models.UserRole.NURSE, models.UserRole.DOCTOR]))],
)
async def create_patient(
    *,
    db: AsyncSession = Depends(deps.get_db),
    patient_in: schemas.PatientCreate,
):
    """
    Register a new patient (Nurse role required).
    The PRD mentions a warning for duplicates but allowing it,
    which is handled by this logic (no unique constraint on name+phone).
    """
    patient = await crud.patient.create(db=db, obj_in=patient_in)
    return patient

@router.get(
    "/search",
    response_model=List[schemas.PatientLookup],
)
async def search_patients_by_phone(
    phone_number: str,
    db: AsyncSession = Depends(deps.get_db),
    current_user: models.User = Depends(deps.get_current_user),
):
    """
    Patient-picker logic. Searches patients by phone number.
    Accessible by all authenticated users.
    """
    patients = await crud.patient.get_by_phone(db, phone_number=phone_number)
    # This is a placeholder for calculating age and last visit. 
    # A more optimized version might use a database view or function.
    results = []
    for p in patients:
        age = (date.today() - p.date_of_birth).days // 365 if p.date_of_birth else None
        # In a real app, you would query for the last appointment date
        results.append(schemas.PatientLookup(
            id=p.id, full_name=p.full_name, phone_number=p.phone_number,
            age=age, sex=p.sex, last_visit_date=None 
        ))
    return results

@router.get("/{id}", response_model=schemas.Patient)
async def read_patient(
    id: int,
    db: AsyncSession = Depends(deps.get_db),
    current_user: models.User = Depends(deps.get_current_user),
):
    """
    Get patient details. Visibility rules from PRD are applied in history endpoints.
    """
    patient = await crud.patient.get(db=db, id=id)
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")
    return patient

# In app/api/endpoints/patients.py

# ... (keep all your other imports at the top)
from sqlalchemy.orm import selectinload
from typing import List

# ... (keep your router definition and other endpoints)

# --- THIS IS THE FUNCTION TO REPLACE ---
@router.get(
    "/{id}/visits",
    response_model=List[schemas.VisitForDoctor],
    dependencies=[Depends(deps.require_role([models.UserRole.DOCTOR, models.UserRole.NURSE]))]
)
async def read_patient_visits(
    id: int,
    db: AsyncSession = Depends(deps.get_db),
):
    """
    Get all past visits for a specific patient.
    - Eager loads all necessary nested data for the patient history view.
    """
    visits_result = await db.execute(
        select(models.Visit)
        .join(models.Visit.appointment)
        .filter(models.Appointment.patient_id == id)
        .options(
            # Eager load the prescription and its line items
            selectinload(models.Visit.prescription)
            .selectinload(models.Prescription.line_items),
            
            # --- THIS IS THE FINAL FIX ---
            # Also eager load the patient related to the prescription
            selectinload(models.Visit.prescription)
            .selectinload(models.Prescription.patient),
            
            # Eager load the private notes and their author doctor
            selectinload(models.Visit.notes)
            .selectinload(models.ClinicalNote.author_doctor),
            
            # Eager load the doctor who conducted the visit via the appointment
            selectinload(models.Visit.appointment)
            .selectinload(models.Appointment.doctor)
        )
        .order_by(models.Visit.id.desc())
    )

    return visits_result.scalars().all()

# ... (the rest of your file remains the same)

# ... (the rest of your file remains the same)
# --- ADD THIS NEW ENDPOINT ---
@router.get("/{id}/prescriptions", response_model=List[schemas.Prescription])
async def read_patient_prescriptions(
    id: int,
    db: AsyncSession = Depends(deps.get_db),
    current_user: models.User = Depends(deps.get_current_user),
):
    """ Get a patient's prescription history. """
    patient = await crud.patient.get(db=db, id=id)
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")
        
    query = (
        select(models.Prescription)
        .filter(models.Prescription.patient_id == id)
        .options(selectinload(models.Prescription.line_items))
        .order_by(models.Prescription.id.desc())
    )
    result = await db.execute(query)
    return result.scalars().all()