from typing import Generator, List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from datetime import timedelta, datetime
from sqlalchemy import func
from app import schemas, crud, db
from app.db import models # <-- Be more specific
from app.api import deps
from app.socket_manager import notify_user, notify_pharmacy

router = APIRouter()

# app/api/endpoints/appointments.py (CORRECTED & FINAL)

# (Make sure the imports at the top of the file are updated as per Step 1)
# from app.db import models

# app/api/endpoints/appointments.py (DEFINITIVE & FINAL)

# ... (imports should be correct from previous steps: `from app.db import models`, etc.) ...

# In app/api/endpoints/appointments.py

# ... (keep all your imports and the router definition) ...

@router.post(
    "/",
    response_model=schemas.Appointment,
    dependencies=[Depends(deps.require_role([models.UserRole.NURSE, models.UserRole.DOCTOR]))],
)
async def create_appointment(
    *,
    db: AsyncSession = Depends(deps.get_db),
    appointment_in: schemas.AppointmentCreate,
    current_user: models.User = Depends(deps.get_current_user)
):
    """
    Create a new appointment (Nurse or Doctor).
    """
    appointment_data = appointment_in.dict()
    appointment_data['created_by_id'] = current_user.id
    db_obj = models.Appointment(**appointment_data)

    db.add(db_obj)
    await db.commit()
    await db.refresh(db_obj)
    
    # --- THIS IS THE FIX ---
    # We must explicitly refresh ALL relationships that the response_model needs.
    # Since schemas.Appointment now includes 'visit', we must add it here.
    await db.refresh(db_obj, attribute_names=['patient', 'doctor', 'visit'])
    
    appointment = db_obj 

    await notify_user(
        appointment.doctor_id,
        "new_appointment",
        {"appointment_id": appointment.id, "patient_name": appointment.patient.full_name},
    )
    return appointment

# ... (the rest of your file, including the corrected read_appointments, remains the same) ...

# In app/api/endpoints/appointments.py

# ... (keep all your other imports at the top)
from sqlalchemy import func
from datetime import date

# ... (keep your router definition and other endpoints)

@router.get("/", response_model=List[schemas.Appointment])
async def read_appointments(
    db: AsyncSession = Depends(deps.get_db),
    current_user: models.User = Depends(deps.get_current_user),
    patient_id: Optional[int] = None,
    doctor_id: Optional[int] = None,
    appointment_date: Optional[date] = None,
):
    """
    Get list of appointments with filters.
    - Eager loads all necessary nested data for the dashboard.
    """
    query = select(models.Appointment).options(
        # Eager load the direct relationships
        selectinload(models.Appointment.patient),
        selectinload(models.Appointment.doctor),

        # --- THIS IS THE FINAL FIX ---
        # We extend the chain to go one level deeper, loading the line_items
        # for each prescription at the same time.
        selectinload(models.Appointment.visit)
        .selectinload(models.Visit.prescription)
        .selectinload(models.Prescription.line_items) # <-- ADD THIS FINAL PART
    )

    # Apply filters
    if current_user.role == models.UserRole.DOCTOR and not doctor_id:
        query = query.filter(models.Appointment.doctor_id == current_user.id)
    elif doctor_id:
        query = query.filter(models.Appointment.doctor_id == doctor_id)
        
    if patient_id:
        query = query.filter(models.Appointment.patient_id == patient_id)
    
    if appointment_date:
        query = query.filter(func.date(models.Appointment.appointment_time) == appointment_date)
    
    result = await db.execute(query.order_by(models.Appointment.appointment_time))
    return result.scalars().all()

# ... (rest of the file remains the same)

# --- HELPER FUNCTION FOR STATUS CHANGES ---
async def update_appointment_status(
    id: int, 
    status: models.appointment.AppointmentStatus,
    db: AsyncSession,
    current_user: models.User
) -> models.Appointment:
    appointment = await crud.appointment.get(db=db, id=id)
    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")
    # Simple permission check: Doctor on the appointment or Nurse/Admin can cancel.
    if not (current_user.role in [models.UserRole.NURSE, models.UserRole.ADMIN] or appointment.doctor_id == current_user.id):
        raise HTTPException(status_code=403, detail="Not authorized to modify this appointment")
    
    appointment.status = status
    await db.commit()
    await db.refresh(appointment)
    return appointment

# ...
@router.put("/{id}/status/cancel", response_model=schemas.Appointment)
async def cancel_appointment(
    id: int,
    db: AsyncSession = Depends(deps.get_db),
    current_user: models.User = Depends(deps.require_role([models.UserRole.DOCTOR, models.UserRole.NURSE])),
):
    appointment = await update_appointment_status(id, models.appointment.AppointmentStatus.CANCELLED, db, current_user)
    
    # Create audit log
    log_entry = schemas.AuditLogCreate(
        user_id=current_user.id, 
        action="APPOINTMENT_CANCELLED", 
        entity="Appointment", 
        entity_id=id
    )
    await crud.audit_log.create(db, obj_in=log_entry)
    
    return appointment


@router.put("/{id}/status/no-show", response_model=schemas.Appointment)
async def mark_appointment_no_show(
    id: int,
    db: AsyncSession = Depends(deps.get_db),
    current_user: models.User = Depends(deps.require_role([models.UserRole.DOCTOR, models.UserRole.NURSE])),
):
    """ Mark an appointment as a no-show. """
    return await update_appointment_status(id, models.appointment.AppointmentStatus.NO_SHOW, db, current_user)
# app/api/endpoints/appointments.py (CORRECTED & FINAL `start_consultation`)

# In app/api/endpoints/appointments.py

# ... (keep all your other imports and endpoints)

@router.put("/{id}/status/start", response_model=schemas.Appointment)
async def start_consultation(
    id: int,
    db: AsyncSession = Depends(deps.get_db),
    current_user: models.User = Depends(deps.require_role([models.UserRole.DOCTOR])),
):
    """
    Doctor starts the consultation, creating a new Visit record.
    Returns the fully-loaded Appointment object.
    """
    # First, get the appointment to perform checks
    initial_result = await db.execute(
        select(models.Appointment)
        .options(selectinload(models.Appointment.visit))
        .filter(models.Appointment.id == id)
    )
    appointment = initial_result.scalars().first()

    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")
    if appointment.doctor_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized for this appointment")
    if appointment.visit:
        raise HTTPException(status_code=400, detail="Consultation has already been started.")

    # Update status and create the visit in the database
    appointment.status = models.appointment.AppointmentStatus.IN_CONSULTATION
    new_visit = models.Visit()
    appointment.visit = new_visit
    db.add(appointment)
    await db.commit() # Commit the changes to the database

    # --- THIS IS THE FINAL FIX ---
    # After committing, the new visit exists. Now, re-fetch the entire appointment
    # from the database with ALL relationships needed for the response model eagerly loaded.
    # This is the only guaranteed way to prevent all lazy-loading errors.
    final_result = await db.execute(
        select(models.Appointment)
        .filter(models.Appointment.id == id)
        .options(
            selectinload(models.Appointment.patient),
            selectinload(models.Appointment.doctor),
            selectinload(models.Appointment.visit)
            .selectinload(models.Visit.prescription) # This will correctly load None
            .selectinload(models.Prescription.line_items) # Chaining for future safety
        )
    )
    
    updated_appointment = final_result.scalars().first()
    return updated_appointment

# In app/api/endpoints/appointments.py

# ... (keep all your other imports and endpoints)

@router.put(
    "/{id}/status/complete", # We keep the same URL for simplicity
    response_model=schemas.Msg,
)
async def save_visit_details( # Renamed for clarity
    id: int,
    payload: schemas.CompleteVisitPayload,
    db: AsyncSession = Depends(deps.get_db),
    current_user: models.User = Depends(deps.require_role([models.UserRole.DOCTOR])),
):
    """
    Doctor saves or updates visit details (notes, prescription).
    This endpoint is now idempotent and respects prescription status.
    """
    # Use a single comprehensive query to get everything we need to check
    result = await db.execute(
        select(models.Appointment)
        .options(
            selectinload(models.Appointment.visit)
            .selectinload(models.Visit.prescription)
            .selectinload(models.Prescription.line_items)
        )
        .filter(models.Appointment.id == id)
    )
    appointment = result.scalars().first()
    
    if not appointment or not appointment.visit:
        raise HTTPException(status_code=404, detail="Consultation not found or was not properly started.")
    if appointment.doctor_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to complete this visit.")

    visit = appointment.visit
    existing_prescription = visit.prescription

    # --- CRITICAL VALIDATION LOGIC ---
    if existing_prescription and existing_prescription.status == models.PrescriptionStatus.FULLY_DISPENSED:
        raise HTTPException(status_code=403, detail="Cannot edit a visit with a fully dispensed prescription.")

    # --- Update Visit and Appointment Status ---
    appointment.status = models.appointment.AppointmentStatus.COMPLETED
    visit_data = payload.visit_details.dict(exclude_unset=True)
    private_note_content = visit_data.pop("private_note", None)
    for key, value in visit_data.items():
        setattr(visit, key, value)
    
    # --- Handle Prescription Creation / Update ---
    if payload.prescription_details and payload.prescription_details.line_items:
        if not existing_prescription:
            # --- CREATE SCENARIO ---
            new_prescription = models.Prescription(
                visit_id=visit.id,
                patient_id=appointment.patient_id,
                doctor_id=current_user.id,
            )
            for item in payload.prescription_details.line_items:
                new_prescription.line_items.append(models.PrescriptionLineItem(**item.dict()))
            db.add(new_prescription)
            await notify_pharmacy("new_prescription", {"prescription_id": new_prescription.id, "patient_name": appointment.patient.full_name})
        else:
            # --- UPDATE SCENARIO ---
            # A robust way to sync: delete undispensed items and re-add from payload.
            
            # 1. Filter out and keep the items that have already been dispensed.
            dispensed_items = [item for item in existing_prescription.line_items if item.status != models.DispenseLineStatus.NOT_GIVEN]
            
            # 2. Get the new/updated items from the payload.
            new_items_from_payload = [models.PrescriptionLineItem(**item.dict()) for item in payload.prescription_details.line_items]
            
            # 3. Combine them: the already dispensed items + the new list from the doctor.
            existing_prescription.line_items = dispensed_items + new_items_from_payload
    else:
        # If the doctor submits an empty prescription list, remove any existing undispensed items.
        if existing_prescription:
            existing_prescription.line_items = [item for item in existing_prescription.line_items if item.status != models.DispenseLineStatus.NOT_GIVEN]


    await db.commit()
    
    return schemas.Msg(msg="Visit details saved successfully.")