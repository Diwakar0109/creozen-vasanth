from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app import crud, schemas, db
from app.api import deps

router = APIRouter()

@router.get("/", response_model=List[schemas.Hospital], dependencies=[Depends(deps.require_role([db.models.UserRole.ADMIN]))])
async def read_hospitals(
    db: AsyncSession = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100,
):
    """ Get a list of all hospitals. Admin only. """
    hospitals = await crud.hospital.get_multi(db, skip=skip, limit=limit)
    return hospitals

@router.put("/{id}", response_model=schemas.Hospital, dependencies=[Depends(deps.require_role([db.models.UserRole.ADMIN]))])
async def update_hospital(
    id: int,
    hospital_in: schemas.HospitalUpdate,
    db: AsyncSession = Depends(deps.get_db),
):
    """ Update hospital details. Admin only. """
    hospital = await crud.hospital.get(db, id=id)
    if not hospital:
        raise HTTPException(status_code=404, detail="Hospital not found")
    hospital = await crud.hospital.update(db, db_obj=hospital, obj_in=hospital_in)
    return hospital