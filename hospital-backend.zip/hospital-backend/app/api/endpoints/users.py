from typing import List, Optional, Any 
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app import schemas, crud
from app.api import deps
from app.db import models

router = APIRouter()

@router.get("/me", response_model=schemas.User)
async def read_user_me(
    current_user: models.User = Depends(deps.get_current_user),
) -> Any:
    """
    Get current user.
    """
    return current_user

# --- ADD THIS NEW ENDPOINT ---
@router.get("/", response_model=List[schemas.User], dependencies=[Depends(deps.require_role([models.UserRole.ADMIN, models.UserRole.NURSE]))])
async def read_users(
    db: AsyncSession = Depends(deps.get_db),
    role: Optional[models.UserRole] = None,
    hospital_id: Optional[int] = None,
):
    """ Get a list of users with optional filters for role and hospital. Admin only. """
    query = select(models.User)
    if role:
        query = query.filter(models.User.role == role)
    if hospital_id:
        query = query.filter(models.User.hospital_id == hospital_id)
    
    result = await db.execute(query)
    return result.scalars().all()

# --- ADD THIS NEW ENDPOINT ---
@router.get("/{id}", response_model=schemas.User, dependencies=[Depends(deps.require_role([models.UserRole.ADMIN]))])
async def read_user_by_id(id: int, db: AsyncSession = Depends(deps.get_db)):
    """ Get user by ID. Admin only. """
    user = await crud.user.get(db, id=id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

# --- ADD THIS NEW ENDPOINT for activation/deactivation ---
@router.put("/{id}", response_model=schemas.User, dependencies=[Depends(deps.require_role([models.UserRole.ADMIN]))])
async def update_user(
    id: int,
    user_in: schemas.UserUpdate,
    db: AsyncSession = Depends(deps.get_db),
):
    """ Update user details (e.g., activate/deactivate). Admin only. """
    user = await crud.user.get(db, id=id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user = await crud.user.update(db, db_obj=user, obj_in=user_in)
    return user

# --- ADD THIS NEW ENDPOINT ---
@router.post("/{id}/reset-password", response_model=schemas.Msg, dependencies=[Depends(deps.require_role([models.UserRole.ADMIN]))])
async def reset_user_password(id: int, db: AsyncSession = Depends(deps.get_db)):
    """
    (Admin) Reset a user's password.
    NOTE: In a real system, this would trigger a secure email flow.
    For this implementation, we can log the action or set a temporary password.
    """
    # This is a placeholder for a more secure flow.
    # For now, it simply confirms the action is possible.
    user = await crud.user.get(db, id=id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    # Add logic here to generate a temp password or send an email
    return {"msg": f"Password reset initiated for user {user.email}"}

# Keep your existing POST / endpoint for creating users
@router.post(
    "/",
    response_model=schemas.User,
    dependencies=[Depends(deps.require_role([models.user.UserRole.ADMIN]))],
)
async def create_user(
    *,
    db: AsyncSession = Depends(deps.get_db),
    user_in: schemas.UserCreate,
):
    """
    Create new user (Doctor, Nurse, etc.). Admin only.
    """
    user = await crud.user.get_by_email(db, email=user_in.email)
    if user:
        raise HTTPException(
            status_code=400,
            detail="The user with this email already exists in the system.",
        )
    user = await crud.user.create(db, obj_in=user_in)
    return user